package com.example.ofrisproject;

public interface RegisterCallback {
    void authenticateResult(boolean success);
}
