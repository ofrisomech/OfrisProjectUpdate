package com.example.ofrisproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void MoveToHomePage(View view){

        // read input from edit text
        EditText etName=findViewById(R.id.editTextTextPersonName);
        String Name= etName.getText().toString();
        EditText etMail = findViewById(R.id.editTextTextEmailAddress);
        String mail = etMail.getText().toString();
        EditText etPassword = findViewById(R.id.editTextTextPassword);
        String password = etPassword.getText().toString();
        EditText etPhone = findViewById(R.id.editTextPhone);
        String Phone = etPhone.getText().toString();
        EditText etNickname = findViewById(R.id.editTextTextPersonName2);
        String Nickname = etNickname.getText().toString();


        Toast.makeText(this,mail,Toast.LENGTH_SHORT).show();
        Intent intent= new Intent(this, HomePage.class);
        startActivity(intent);
    }
}

